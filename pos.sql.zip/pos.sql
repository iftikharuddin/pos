-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2016 at 09:25 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pos`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `code`, `image`, `created_at`, `updated_at`) VALUES
(6, 'Material', 'MT#$$', 'public/img/1459852498.jpg', '2016-04-05 05:34:58', '2016-04-05 05:34:58'),
(9, 'Pakistan', 'PK', 'public/img/1459853825.jpg', '2016-04-05 05:57:05', '2016-04-05 05:57:05'),
(10, 'Search Engines', 'SE', 'public/img/1460053806.jpg', '2016-04-07 13:30:06', '2016-04-07 13:30:06'),
(11, 'Waterzy', '34', 'public/img/1460314665.jpg', '2016-04-07 13:30:20', '2016-04-10 13:57:46'),
(12, 'mobile', '08922', 'public/img/1460558890.jpg', '2016-04-13 09:48:10', '2016-04-13 09:48:10'),
(13, 'Horses', '$$$e', 'public/img/1460571031.jpeg', '2016-04-13 13:10:32', '2016-04-13 13:10:32');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2016_04_04_171816_create_product_table', 2),
('2016_04_04_173048_create_products_table', 3),
('2016_04_05_071337_create_categories_table', 4),
('2016_04_05_110842_Settings', 5),
('2016_04_06_124202_create_sales_table', 6),
('2016_04_06_142211_create_orders_table', 6),
('2016_04_06_142450_create_orderdetails_table', 6),
('2016_04_07_172340_create_order_details_table', 7);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `location`, `created_at`, `updated_at`) VALUES
(1, 'Iftikhar uddin', 'Bajaur', NULL, NULL),
(10, 'wos kho warka', 'kanamara', '2016-04-07 12:24:41', '2016-04-07 12:24:41'),
(12, 'Pakistani', 'Bajaur', '2016-04-07 12:28:07', '2016-04-07 12:28:07'),
(14, 'Totty', 'PK', '2016-04-08 00:50:15', '2016-04-08 00:50:15'),
(15, 'John Doe', 'JJ', '2016-04-08 00:51:20', '2016-04-08 00:51:20'),
(16, 'Tarbozasab', 'PK1', '2016-04-08 00:52:37', '2016-04-08 00:52:37'),
(18, 'Botal Khan', 'BJ', '2016-04-08 01:19:58', '2016-04-08 01:19:58'),
(19, 'Joker', 'HERE', '2016-04-08 01:37:22', '2016-04-08 01:37:22'),
(20, 'Joker', 'HERE', '2016-04-08 01:38:11', '2016-04-08 01:38:11'),
(21, 'Johndd', 'ieie', '2016-04-08 01:38:36', '2016-04-08 01:38:36'),
(22, 'testGG', 'test', '2016-04-08 08:18:59', '2016-04-08 08:18:59'),
(23, 'cgg', 'g', '2016-04-08 08:19:30', '2016-04-08 08:19:30'),
(24, 'wjjj', 'jj', '2016-04-08 08:21:05', '2016-04-08 08:21:05'),
(25, 'jang', '1', '2016-04-08 08:22:17', '2016-04-08 08:22:17'),
(26, 'Khnnn', 'G', '2016-04-08 08:24:36', '2016-04-08 08:24:36'),
(27, 'New Customer baby', 'PK', '2016-04-08 08:25:09', '2016-04-08 08:25:09'),
(28, 'New Customer baby', 'PK', '2016-04-08 08:26:12', '2016-04-08 08:26:12'),
(29, 'Lalakhan', '0P', '2016-04-08 08:30:50', '2016-04-08 08:30:50'),
(30, 'GG', '12', '2016-04-08 08:34:06', '2016-04-08 08:34:06'),
(31, 'Heydrat', 'PK', '2016-04-09 02:01:39', '2016-04-09 02:01:39'),
(32, 'GG', 'g', '2016-04-09 02:03:16', '2016-04-09 02:03:16'),
(33, 'Taher', 'sS', '2016-04-09 02:03:51', '2016-04-09 02:03:51'),
(34, 'Gula', 'TT', '2016-04-09 02:05:02', '2016-04-09 02:05:02'),
(35, 'Gulkhan kaak', 'Bajaur', '2016-04-09 02:09:33', '2016-04-09 02:09:33'),
(36, 'Talha Khan', 'PS', '2016-04-10 13:18:45', '2016-04-10 13:18:45'),
(37, 'Misbah', 'WA', '2016-04-11 03:56:26', '2016-04-11 03:56:26'),
(38, 'Gul Khan', 'KK', '2016-04-11 13:44:30', '2016-04-11 13:44:30'),
(39, 'Haris Gul', 'PSS', '2016-04-11 13:54:03', '2016-04-11 13:54:03'),
(40, 'Hurrah', 'HH', '2016-04-11 14:25:09', '2016-04-11 14:25:09'),
(41, 'Jambol', 'Khel', '2016-04-11 14:25:59', '2016-04-11 14:25:59'),
(42, 'Warkakakan', 'OO', '2016-04-11 14:26:27', '2016-04-11 14:26:27'),
(43, 'Jollu', 'pp', '2016-04-11 14:28:09', '2016-04-11 14:28:09'),
(44, 'Lahore', 'khan', '2016-04-11 14:29:20', '2016-04-11 14:29:20'),
(45, 'MagazineKHan', 'pp', '2016-04-11 14:31:11', '2016-04-11 14:31:11'),
(46, 'Lalo Jan', 'PK', '2016-04-11 14:33:09', '2016-04-11 14:33:09'),
(47, 'Talib LAAL', 'LA', '2016-04-12 10:07:10', '2016-04-12 10:07:10'),
(48, 'Torjan', 'JO', '2016-04-12 10:08:32', '2016-04-12 10:08:32'),
(49, 'Killer', 'KL', '2016-04-12 10:11:03', '2016-04-12 10:11:03'),
(50, 'Misbah GUL', 'WAZIR', '2016-04-12 10:13:02', '2016-04-12 10:13:02'),
(51, 'Jasim', 'SW', '2016-04-12 11:54:49', '2016-04-12 11:54:49'),
(52, '', '', '2016-04-13 05:35:25', '2016-04-13 05:35:25'),
(53, 'warkadang', 'PK', '2016-04-13 05:35:51', '2016-04-13 05:35:51'),
(54, 'GG', 'g', '2016-04-13 05:38:47', '2016-04-13 05:38:47'),
(55, '', '', '2016-04-13 05:38:49', '2016-04-13 05:38:49'),
(56, '', '', '2016-04-13 05:38:50', '2016-04-13 05:38:50'),
(57, '', '', '2016-04-13 05:38:51', '2016-04-13 05:38:51'),
(58, '', '', '2016-04-13 05:38:53', '2016-04-13 05:38:53'),
(59, '', '', '2016-04-13 05:38:56', '2016-04-13 05:38:56'),
(60, 'Iftikhar uddin Saib', 'BJ', '2016-04-13 05:50:59', '2016-04-13 05:50:59'),
(61, 'a', 's', '2016-04-13 05:52:34', '2016-04-13 05:52:34'),
(62, '', '', '2016-04-13 06:01:26', '2016-04-13 06:01:26'),
(63, 'Gulaji', 'PP', '2016-04-13 06:01:37', '2016-04-13 06:01:37'),
(64, '', '', '2016-04-13 06:02:37', '2016-04-13 06:02:37'),
(65, '', '', '2016-04-13 06:02:38', '2016-04-13 06:02:38'),
(66, 'Khangul', 'kk', '2016-04-13 06:06:11', '2016-04-13 06:06:11'),
(67, '', '', '2016-04-13 06:06:14', '2016-04-13 06:06:14'),
(68, 'Maulan', 'aka', '2016-04-13 06:08:22', '2016-04-13 06:08:22'),
(69, 'hh', 'h', '2016-04-13 06:09:48', '2016-04-13 06:09:48'),
(70, 'Divkhan', 'DIV', '2016-04-13 06:11:06', '2016-04-13 06:11:06'),
(71, 'Junaid', 'kk', '2016-04-13 06:16:19', '2016-04-13 06:16:19'),
(72, '', '', '2016-04-13 06:17:08', '2016-04-13 06:17:08'),
(73, 'Tengakajquery', 'je', '2016-04-13 06:20:27', '2016-04-13 06:20:27'),
(74, 'afasf', 'sasa', '2016-04-13 06:20:47', '2016-04-13 06:20:47'),
(75, 'Tabahyde', 'STACK', '2016-04-13 06:33:53', '2016-04-13 06:33:53'),
(76, 'Jokersab', 'bATMAN', '2016-04-13 06:36:44', '2016-04-13 06:36:44'),
(77, 'Jobykhan', 'iiee', '2016-04-13 06:39:05', '2016-04-13 06:39:05'),
(78, 'JabirK', 'hh', '2016-04-13 06:40:58', '2016-04-13 06:40:58'),
(79, '', '', '2016-04-13 06:41:01', '2016-04-13 06:41:01'),
(80, 'Cool', 'MAN', '2016-04-13 06:42:49', '2016-04-13 06:42:49'),
(81, 'Genghis', 'KHan', '2016-04-13 06:53:39', '2016-04-13 06:53:39'),
(82, 'Hite', 'ghgh', '2016-04-13 06:54:38', '2016-04-13 06:54:38'),
(83, 'FOrmer', 'gg', '2016-04-13 07:11:36', '2016-04-13 07:11:36'),
(84, 'Jangeray', '99', '2016-04-13 07:25:02', '2016-04-13 07:25:02'),
(85, 'pussy', 'cat', '2016-04-13 07:32:43', '2016-04-13 07:32:43'),
(86, 'Kunatawor', 'oo', '2016-04-13 07:33:04', '2016-04-13 07:33:04'),
(87, 'Agau', 'b', '2016-04-13 07:33:59', '2016-04-13 07:33:59'),
(88, 'tecg', 'tg', '2016-04-13 07:35:01', '2016-04-13 07:35:01'),
(89, 'Damn', 'it', '2016-04-13 07:36:21', '2016-04-13 07:36:21'),
(90, '', '', '2016-04-13 07:36:43', '2016-04-13 07:36:43'),
(91, '', '', '2016-04-13 08:43:10', '2016-04-13 08:43:10'),
(92, 'Mukab', 'KK', '2016-04-13 08:45:51', '2016-04-13 08:45:51'),
(93, 'Joker Khan', 'PK', '2016-04-13 08:47:10', '2016-04-13 08:47:10'),
(94, 'Aamir', 'DASH', '2016-04-13 09:21:11', '2016-04-13 09:21:11'),
(95, 'Jasim Sultan', 'PK', '2016-04-13 09:41:37', '2016-04-13 09:41:37'),
(96, 'inzimam khan dawar', 'waziristan', '2016-04-13 09:49:31', '2016-04-13 09:49:31'),
(97, '', '', '2016-04-13 09:50:35', '2016-04-13 09:50:35'),
(98, 'Halib', 'JO', '2016-04-13 13:58:09', '2016-04-13 13:58:09'),
(99, 'John Doe', 'HR', '2016-04-13 14:00:03', '2016-04-13 14:00:03'),
(100, 'Holla', 'h', '2016-04-13 14:05:11', '2016-04-13 14:05:11'),
(101, 'Killer', 'k', '2016-04-13 14:06:27', '2016-04-13 14:06:27'),
(102, 'Josen', 'JJ', '2016-04-13 14:45:42', '2016-04-13 14:45:42'),
(103, 'Cooler ', 'KHAN', '2016-04-13 15:07:47', '2016-04-13 15:07:47'),
(104, '', '', '2016-04-14 06:19:45', '2016-04-14 06:19:45'),
(105, '', '', '2016-04-14 06:33:22', '2016-04-14 06:33:22'),
(106, 'Mr John Doe', 'America', '2016-04-14 06:35:10', '2016-04-14 06:35:10'),
(107, 'Gulamir', 'HH', '2016-04-14 12:20:07', '2016-04-14 12:20:07'),
(108, 'Akshy Kumar', 'KHAN', '2016-04-14 12:24:31', '2016-04-14 12:24:31'),
(109, 'Inayat', '', '2016-04-14 12:26:22', '2016-04-14 12:26:22'),
(110, 'Gulistan', 'Orakzai', '2016-04-14 12:35:40', '2016-04-14 12:35:40');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE IF NOT EXISTS `order_details` (
  `id` int(10) unsigned NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `unitprice` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `discount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `quantity`, `unitprice`, `discount`, `amount`, `created_at`, `updated_at`) VALUES
(99, 84, 4, '2', '999', '0', '1998', '2016-04-13 07:25:02', '2016-04-13 07:25:02'),
(100, 84, 5, '122', '5', '', '610', '2016-04-13 07:25:02', '2016-04-13 07:25:02'),
(101, 85, 4, '22', '999', '0', '21978', '2016-04-13 07:32:44', '2016-04-13 07:32:44'),
(102, 86, 4, '2', '999', '0', '1998', '2016-04-13 07:33:04', '2016-04-13 07:33:04'),
(103, 87, 4, '222', '999', '2', '217342.44', '2016-04-13 07:33:59', '2016-04-13 07:33:59'),
(104, 88, 5, '22', '5', '', '110', '2016-04-13 07:35:01', '2016-04-13 07:35:01'),
(105, 89, 5, '2', '5', '2', '9.8', '2016-04-13 07:36:22', '2016-04-13 07:36:22'),
(106, 90, 5, '222', '5', '22', '865.8', '2016-04-13 07:36:43', '2016-04-13 07:36:43'),
(107, 90, 3, '1', '34', '1', '33.66', '2016-04-13 07:36:43', '2016-04-13 07:36:43'),
(108, 91, 3, '', '', '', '', '2016-04-13 08:43:11', '2016-04-13 08:43:11'),
(109, 92, 4, '2', '999', '0', '1998', '2016-04-13 08:45:51', '2016-04-13 08:45:51'),
(110, 93, 4, '2', '999', '0', '1998', '2016-04-13 08:47:10', '2016-04-13 08:47:10'),
(111, 93, 3, '3', '888', '12', '2344.32', '2016-04-13 08:47:10', '2016-04-13 08:47:10'),
(112, 94, 5, '12', '5', '0', '60', '2016-04-13 09:21:11', '2016-04-13 09:21:11'),
(113, 94, 4, '1', '999', '0', '999', '2016-04-13 09:21:11', '2016-04-13 09:21:11'),
(114, 95, 4, '2', '999', '0', '1998', '2016-04-13 09:41:37', '2016-04-13 09:41:37'),
(115, 95, 5, '12', '5', '0', '60', '2016-04-13 09:41:37', '2016-04-13 09:41:37'),
(116, 96, 3, '', '', '', '', '2016-04-13 09:49:31', '2016-04-13 09:49:31'),
(117, 97, 5, '3', '5', '1', '14.85', '2016-04-13 09:50:35', '2016-04-13 09:50:35'),
(118, 97, 6, '2', '12000', '1', '23760', '2016-04-13 09:50:35', '2016-04-13 09:50:35'),
(119, 98, 5, '2', '5', '0', '10', '2016-04-13 13:58:09', '2016-04-13 13:58:09'),
(120, 98, 4, '2', '999', '0', '1998', '2016-04-13 13:58:09', '2016-04-13 13:58:09'),
(121, 99, 3, '22', '34', '', '748', '2016-04-13 14:00:03', '2016-04-13 14:00:03'),
(122, 99, 5, '12', '5', '0', '60', '2016-04-13 14:00:03', '2016-04-13 14:00:03'),
(123, 99, 6, '1', '12000', '0', '12000', '2016-04-13 14:00:04', '2016-04-13 14:00:04'),
(124, 100, 4, '2', '999', '0', '1998', '2016-04-13 14:05:11', '2016-04-13 14:05:11'),
(125, 100, 5, '2', '5', '', '10', '2016-04-13 14:05:11', '2016-04-13 14:05:11'),
(126, 101, 4, '2', '999', '0', '1998', '2016-04-13 14:06:27', '2016-04-13 14:06:27'),
(127, 101, 5, '12', '5', '0', '60', '2016-04-13 14:06:27', '2016-04-13 14:06:27'),
(128, 102, 4, '2', '999', '0', '1998', '2016-04-13 14:45:42', '2016-04-13 14:45:42'),
(129, 103, 4, '2', '999', '0', '1998', '2016-04-13 15:07:47', '2016-04-13 15:07:47'),
(130, 103, 5, '3', '5', '0', '15', '2016-04-13 15:07:47', '2016-04-13 15:07:47'),
(131, 104, 4, '12', '999', '0', '11988', '2016-04-14 06:19:45', '2016-04-14 06:19:45'),
(132, 104, 5, '2', '5', '', '10', '2016-04-14 06:19:45', '2016-04-14 06:19:45'),
(133, 105, 3, '', '', '', '', '2016-04-14 06:33:22', '2016-04-14 06:33:22'),
(134, 106, 5, '2', '5', '0', '10', '2016-04-14 06:35:10', '2016-04-14 06:35:10'),
(135, 106, 5, '12', '5', '0', '60', '2016-04-14 06:35:10', '2016-04-14 06:35:10'),
(136, 106, 6, '2', '12000', '0', '24000', '2016-04-14 06:35:10', '2016-04-14 06:35:10'),
(137, 107, 5, '2', '5', '0', '10', '2016-04-14 12:20:07', '2016-04-14 12:20:07'),
(138, 108, 6, '2', '12000', '2', '23520', '2016-04-14 12:24:31', '2016-04-14 12:24:31'),
(139, 108, 4, '1', '999', '', '999', '2016-04-14 12:24:31', '2016-04-14 12:24:31'),
(140, 109, 4, '2', '999', '0', '1998', '2016-04-14 12:26:22', '2016-04-14 12:26:22'),
(141, 109, 5, '12', '5', '0', '60', '2016-04-14 12:26:22', '2016-04-14 12:26:22'),
(142, 110, 5, '22', '5', '0', '110', '2016-04-14 12:35:40', '2016-04-14 12:35:40'),
(143, 110, 6, '1', '12000', '1', '11880', '2016-04-14 12:35:40', '2016-04-14 12:35:40');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `desc`, `price`, `quantity`, `created_at`, `updated_at`) VALUES
(3, 'Mac Apple v 12', 'Laptop Core i9 is a great lappy in Market', '34', '12', '2016-04-04 12:47:42', '2016-04-04 13:05:08'),
(4, 'Magazine 40', 'This is a unique item in market which holds 44 magazines and 300 bullets', '999', '22', '2016-04-04 12:48:30', '2016-04-06 09:54:12'),
(5, 'Naswawr', 'Tabahy production', '5', '2', '2016-04-07 13:30:53', '2016-04-07 13:30:53'),
(6, 'samsung s3', 'galaxy product ', '12000', '9', '2016-04-13 09:45:37', '2016-04-13 09:45:37');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL,
  `companyname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `companyname`, `created_at`, `updated_at`) VALUES
(1, 'Point OF SALE', NULL, '2016-04-13 14:58:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `admin`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Iftikhar uddin', 'admin@gmail.com', '$2y$10$14TZc6OhmjfTXis/eUIeMu6Y0VULUo1UI1XIGg5ome4nlXGuTXB1e', 1, 'MkBuWxPLVFeUCFAMfG2Oq6v3rMYdeeNgPfyzpVAqMtze3yt7hO4krUWbOQzp', '2016-04-03 20:27:35', '2016-04-13 15:00:38'),
(8, 'Talhakhan', 'talha@gmail.com', '$2y$10$mpmFSKxhGF4YhigBfnsEqe6KdlEDKIRlMBy7enRnv34Qi7pOYZ2Ei', 0, NULL, '2016-04-04 07:30:56', '2016-04-04 08:47:00'),
(9, 'John Doe', 'johndoe@gmail.com', '$2y$10$c3r2odoDL/1.evAobWemAuk5LX59LaI/zR8gmL1O572ScLII.HevC', 0, 'SZ1co3QIdYGxbESX3Sg4XJyY7AVwCN72PfhevOzRh3NuqeUh9JgLdeMZI1iH', '2016-04-05 13:28:20', '2016-04-05 13:37:23'),
(10, 'jasim', 'jasimk@gmail.com', '$2y$10$A7kjL2y579w4n1.c/.tTSukcDf02./.J.kU/ENIUmMuEfW8oxckQq', 0, NULL, '2016-04-13 09:52:25', '2016-04-13 09:52:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`), ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=111;
--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=144;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
